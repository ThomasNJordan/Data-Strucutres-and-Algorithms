#include "classic.h"
/*
xx-x
--xx
x-x-
-x--
*/

char** classic::checkCells() {
  char** newBoard;
  // makes copy of m_board
  for (int i = 0; i < getRows(); i++) {
    for (int j = 0; j < getCols(); j++) {
      newBoard[i][j] = m_board[i][j];
    }
  }
  int counter = 0;
  for (int i = 0; i < getRows(); i++) {
    for (int j = 0; j < getCols(); j++) {
      // Logic after && is to check if cell is out of bounds
      if (m_board[i+1][j] == 'X' && i!= getRows()) { // foward one
        counter++;
      }
      if (m_board[i-1][j] == 'X' && i!=0) { // back one
        counter++;
      }
      if (m_board[i][j+1] == 'X' && j!=getCols()) { // up one
        counter++;
      }
      if (m_board[i][j-1] == 'X' && j!=0) { // down one
        counter++;
      }
      if (m_board[i-1][j-1] == 'X' && (i!= 0 || j!= 0)) { // bottem left
        counter++;
      }
      if (m_board[i+1][j-1] == 'X' && (i!= getRows() || j!= 0)) { // bottem right
        counter++;
      }
      if (m_board[i-1][j+1] == 'X' && (i!= 0 || j!= getCols())) { // top left
        counter++;
      }
      if (m_board[i+1][j+1] == 'X' && (i!= getRows() || j!= getCols())) { // top right
        counter++;
      }

      // logic here
      if (counter <= 1) {
        newBoard[i][j] == '-';
      }
      if (counter == 3) {
        newBoard[i][j] == 'X';
      }
      if (counter >= 4) {
        newBoard[i][j] == '-';
      }
      counter = 0;
    }
  }
  return newBoard;
}

classic::~classic() {
  for(int i = 0; i < getRows(); i++){
    delete[] newBoard[i];
  }
  delete[] newBoard;
}

int main() {
  classic c;
  c.createBoard(5,5);
  cout << "before" << endl;
  //c.checkCells();
  cout << "after" << endl;
  return 0;
}
