#include "classic.h"

class donut : public classic {
public:
  void checkCells();
};
