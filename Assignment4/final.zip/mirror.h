#include "classic.h"

class mirror : public classic {
public:
  void checkCells();
};
