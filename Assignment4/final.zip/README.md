# Assignment 4  
Name: Thomas Jordan  
ID: 002400895  
Collaborators: Jacqueline Vu  
Errors: N/A  
Resources:
- https://www.cplusplus.com/reference/fstream/ifstream/
- https://stackoverflow.com/questions/9878965/rand-between-0-and-1

List of Files:
- cell.cpp
- cell.h
- board.cpp
- board.h
- classic.cpp
- classic.h
- donut.cpp
- donut.h
- mirror.cpp
- mirror.h
- config.cpp
- config.h
- mainprogram.cpp
